$ErrorActionPreference = 'Stop'
$projectDir = "d:\ai  clander project"
$downloadsZip = "C:\Users\abdul\Downloads\ai_calendar_project.zip"
$localZip = "$projectDir\ai_calendar_project_complete.zip"
$artifactZip = "C:\Users\abdul\.gemini\antigravity-ide\brain\703f3754-e444-484c-9bbf-70efe1b9abde\ai_calendar_project.zip"

$items = Get-ChildItem -Path $projectDir | Where-Object { 
    $_.Name -ne 'node_modules' -and 
    $_.Name -ne '.bin' -and 
    $_.Extension -ne '.zip' -and
    $_.Name -ne 'local_downloads'
}

Write-Host "Packaging $($items.Count) top-level project items..."
Compress-Archive -Path $items.FullName -DestinationPath $downloadsZip -Force
Write-Host "Created: $downloadsZip"

Compress-Archive -Path $items.FullName -DestinationPath $localZip -Force
Write-Host "Created: $localZip"

if (Test-Path "C:\Users\abdul\.gemini\antigravity-ide\brain\703f3754-e444-484c-9bbf-70efe1b9abde") {
    Copy-Item -Path $downloadsZip -Destination $artifactZip -Force
    Write-Host "Created: $artifactZip"
}

Write-Host "ALL_DONE_SUCCESSFULLY"
